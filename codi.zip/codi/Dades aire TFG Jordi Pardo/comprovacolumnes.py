import pandas as pd

df = pd.read_csv("NO2Bcn.csv", encoding="utf-8", sep=";|,", engine="python")
print("Columnes:", df.columns.tolist())
print(df.head())