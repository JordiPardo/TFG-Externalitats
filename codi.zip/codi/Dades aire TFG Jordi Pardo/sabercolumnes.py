import pandas as pd

# Ruta al fitxer
fitxer = "/Users/jordipardo/Desktop/tfg/dades aire/madridaire2014.csv"

# Carreguem el fitxer
df = pd.read_csv(fitxer, encoding="latin1")

# Mostrem les columnes
print("Columnes del CSV:")
print(df.columns.tolist())