import pandas as pd
import unicodedata

# 📥 Carrega el fitxer Excel netejat o original
df = pd.read_excel("accidents_barcelona_netejat.xlsx")  # O pots posar el fitxer original

# 🎯 Llista exacta de valors únics
print("\n🎯 Valors originals de 'Tipus accident':")
for val in df['Tipus accident'].dropna().unique():
    print(f"- {repr(val)}")

print("\n🎯 Valors originals de 'Districte':")
for val in df['Districte'].dropna().unique():
    print(f"- {repr(val)}")

# 🔎 Opcional: mostra detall unicode d’un valor concret
def mostra_detalls(text):
    print(f"\n🔤 Valor: {repr(text)}")
    for i, c in enumerate(text):
        print(f"  Pos {i}: {repr(c)} → {unicodedata.name(c, 'UNKNOWN')}")

# Exemple: comprova un valor sospitós (canvia l'índex si cal)
print("\n🔬 Exemple detall caràcter per caràcter:")
mostra_detalls(df['Districte'].dropna().unique()[3])

# 📛 Comprovació de valors que semblen iguals però no ho són exactament
print("\n📛 Valors que són iguals visualment però diferents realment:")
valors_districte = df['Districte'].dropna().unique()

for i in range(len(valors_districte)):
    for j in range(i + 1, len(valors_districte)):
        a, b = valors_districte[i], valors_districte[j]
        if a.strip().lower() == b.strip().lower() and a != b:
            print(f"❗ Diferents però semblants: {repr(a)} vs {repr(b)}")