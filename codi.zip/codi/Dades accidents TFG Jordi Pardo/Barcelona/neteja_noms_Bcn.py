import pandas as pd

# 📥 Carrega l’Excel original
df = pd.read_excel("accidents_Barcelona_unificat.xlsx", sheet_name="Accidents BCN")

# 🔤 Funció per intentar arreglar codificació errònia
def neteja_text(text):
    if isinstance(text, str):
        try:
            return text.encode('latin1').decode('utf-8')
        except:
            return text
    return text

# 🧼 Neteja bàsica de les columnes de text
for col in ['Tipus accident', 'Districte']:
    if col in df.columns:
        df[col] = df[col].apply(neteja_text)

# 🔁 Substitucions literals – TIPUS ACCIDENT
substitucions_tipus = {
    'col.lisi¢ frontal': 'col·lisió frontal',
    'col.lisi¢ lateral': 'col·lisió lateral',
    'col.lisi¢ fronto-lateral': 'col·lisió fronto-lateral',
    'col.lisió frontal': 'col·lisió frontal',
    'col.lisió lateral': 'col·lisió lateral',
    'col.lisió fronto-lateral': 'col·lisió fronto-lateral',
    'col.lisió múltiple': 'col·lisió múltiple',
    'col·lisiÃ³': 'col·lisió',
    'col.lisiã³ frontal': 'col·lisió frontal',
    'xoc contra element esttic': 'xoc contra element estàtic',
    'xoc contra element estÃ tic': 'xoc contra element estàtic',
    'bolcada (m\x82s de dues rodes)': 'bolcada (més de dues rodes)',
    'bolcada (mâ€™s de dues rodes)': 'bolcada (més de dues rodes)',
}

# 🔁 Substitucions literals – DISTRICTE
substitucions_districte = {
    'Gr\x85Cia': 'Gràcia',
    'GrCia': 'Gràcia',
    'Sants-Montju\x8bC': 'Sants-Montjuïc',
    'Sants-MontjuC': 'Sants-Montjuïc',
    'Sants-Montjuã¯C': 'Sants-Montjuïc',
    'Sarri\x85-Sant Gervasi': 'Sarrià-Sant Gervasi',
    'Sarri-Sant Gervasi': 'Sarrià-Sant Gervasi',
    'Sant Mart¡': 'Sant Martí',
    'Horta-Guinard¢': 'Horta-Guinardó',
}

df.replace(substitucions_tipus, inplace=True)
df.replace(substitucions_districte, inplace=True)

# ✨ Neteja final
df['Tipus accident'] = (
    df['Tipus accident']
    .str.strip()
    .str.lower()
    .str.replace("col.lisió", "col·lisió", regex=False)
    .str.replace("col.lisi¢", "col·lisió", regex=False)
    .str.replace("col.lisiã³", "col·lisió", regex=False)
    .str.replace("esttic", "estàtic", regex=False)
    .str.replace("estÃ tic", "estàtic", regex=False)
    .str.replace("m\x82s", "més", regex=False)
    .str.replace("mâ€™s", "més", regex=False)
    .str.replace("\xa0", " ")
)

df['Districte'] = (
    df['Districte']
    .str.strip()
    .str.title()
    .str.replace("\xa0", " ")
)

# 🧽 Correcció final de caràcters trencats comuns (dièresis, accents)
for col in ['Tipus accident', 'Districte']:
    df[col] = (
        df[col]
        .str.replace("Ã¯", "ï")
        .str.replace("Ã­", "í")
        .str.replace("Ã¡", "á")
        .str.replace("Ã¨", "è")
        .str.replace("Ã²", "ò")
        .str.replace("Ã€", "À")
        .str.replace("Ã§", "ç")
        .str.replace("Ã¼", "ü")
        .str.replace("Ã£", "ã")
        .str.replace("Ã", "à")
    )

# 🔁 Correcció final dels últims valors identificats
df['Districte'] = df['Districte'].replace({
    'Sants-Montju\x8bC': 'Sants-Montjuïc',
    'Gr\x85Cia': 'Gràcia'
})

# 💾 Desa l’arxiu netejat
df.to_excel("accidents_barcelona_netejat.xlsx", index=False)
print("✅ Fitxer netejat desat com a 'accidents_barcelona_netejat.xlsx'")

# 🔍 Verificació final
print("\n✔️ Districte únics:")
print(sorted(df['Districte'].dropna().unique()))

print("\n✔️ Tipus accident únics:")
print(sorted(df['Tipus accident'].dropna().unique()))