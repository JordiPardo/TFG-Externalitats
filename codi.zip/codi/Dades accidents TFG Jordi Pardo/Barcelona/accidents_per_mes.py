import pandas as pd
import unicodedata

# 📥 Carrega el fitxer netejat
df = pd.read_excel("accidents_barcelona_netejat.xlsx")

# 🔤 Funció per treure accents i diacrítics
def normalitza(text):
    if isinstance(text, str):
        return unicodedata.normalize('NFKD', text.lower()).encode('ascii', 'ignore').decode('utf-8')
    return text

# 📆 Mesos en ordre (normalitzats, sense accents)
ordre_meses = [
    'gener', 'febrer', 'marc', 'abril', 'maig', 'juny',
    'juliol', 'agost', 'setembre', 'octubre', 'novembre', 'desembre'
]

# 🔄 Afegim columna auxiliar amb versió normalitzada del mes
df['Nom_mes_normalitzat'] = df['Nom_mes'].apply(normalitza)

# 🧮 Agregació
taula_mesos = df.groupby(['Any', 'Nom_mes', 'Nom_mes_normalitzat']).size().reset_index(name="Nombre d'accidents")

# 🧭 Ordenació robusta
taula_mesos['Mes_ordre'] = taula_mesos['Nom_mes_normalitzat'].map({m: i for i, m in enumerate(ordre_meses)})
taula_mesos = taula_mesos.sort_values(by=['Any', 'Mes_ordre']).drop(columns=['Mes_ordre', 'Nom_mes_normalitzat'])

# 💾 Exportació
taula_mesos.to_excel("accidents_barcelona_per_mes.xlsx", index=False)
print("✅ Fitxer 'accidents_barcelona_per_mes.xlsx' creat correctament.")