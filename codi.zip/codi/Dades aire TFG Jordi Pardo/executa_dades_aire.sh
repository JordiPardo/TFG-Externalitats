#!/bin/bash
/Library/Frameworks/Python.framework/Versions/3.13/bin/python3 "/Users/jordipardo/Desktop/tfg/dades aire/DadesAireMadrid.py"